# Readme

这个目录主要用来存放训练中产生的日志文件、Checkpoint，以及一些examples初始化时需要的配置文件。
