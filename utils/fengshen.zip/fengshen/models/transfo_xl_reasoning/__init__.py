# encoding=utf-8
from fengshen.models.transfo_xl_denoise.modeling_transfo_xl_denoise import TransfoXLDenoiseModel as TransfoXLModel
from .generate import deduction_generate, abduction_generate